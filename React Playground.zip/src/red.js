import React, { useState } from 'react';
import './style.css';

const RedElement = () => {
  const [rowCount, setRowCount] = useState(2);
  const [rowData, setRowData] = useState([
    {
      data1: 'Data 1',
      data2: 'Data 2',
      data3: 'Data 3',
      data4: 'Data 4',
      data5: 'Data 5',
    },
    {
      data1: 'Data 6',
      data2: 'Data 7',
      data3: 'Data 8',
      data4: 'Data 9',
      data5: 'Data 10',
    },
  ]);

  const deleteRow = (index) => {
    setRowData((prevData) => prevData.filter((_, i) => i !== index));
    setRowCount((prevCount) => prevCount - 1);
  };

  const addRow = () => {
    setRowCount((prevCount) => prevCount + 1);
    setRowData((prevData) => [
      ...prevData,
      {
        data1: `Data ${rowCount + 1}`,
        data2: `Data ${rowCount + 2}`,
        data3: `Data ${rowCount + 3}`,
        data4: `Data ${rowCount + 4}`,
        data5: `Data ${rowCount + 5}`,
      },
    ]);
  };

  return (
    <div className="red-element" id="redElement">
      <table>
        <thead>
          <tr>
            <th rowspan={rowCount}>
              Header 1
              <br />
              <button className="add-button" onClick={addRow}>
                Add Row
              </button>
            </th>
            <th>Header 2</th>
            <th>Header 3</th>
            <th>Header 4</th>
            <th>Header 5</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {rowData.map((row, index) => (
            <tr key={index}>
              <td>{row.data1}</td>
              <td>{row.data2}</td>
              <td>{row.data3}</td>
              <td>{row.data4}</td>
              <td>{row.data5}</td>
              <td>
                <button
                  className="delete-button"
                  onClick={() => deleteRow(index)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default RedElement;
