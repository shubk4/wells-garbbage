
import React from 'react';
import ReactDOM from 'react-dom';
import RedElement from './red';
import VerticalLine from './VerticalLine';
import SliderComponent from './slider';
ReactDOM.render(
  
  <React.StrictMode>
  <VerticalLine />
  <SliderComponent />
  </React.StrictMode>,
  document.getElementById('root')
);
