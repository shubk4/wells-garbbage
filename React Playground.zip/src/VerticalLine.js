import React, { useState } from 'react';
import RedElement from './red';
import './VerticalLine.css';

const VerticalLine = () => {
  const [startIndex, setStartIndex] = useState(0);

  const handleNext = () => {
    setStartIndex((prevIndex) => prevIndex + 5);
  };

  const handlePrevious = () => {
    setStartIndex((prevIndex) => Math.max(prevIndex - 5, 0));
  };

  const renderRedElements = () => {
    const redElements = [];
    for (let i = startIndex; i < startIndex + 5; i++) {
      redElements.push(<RedElement key={i} />);//yaha kar dena shai naye naye elements daal ke naya banane ke liye
    }
    return redElements;
  };

  return (
    <div className="vertical-line">
      <div className="red-elements-container">
        {renderRedElements()}
      </div>
      <div className="button-container">
        <button className="prev-button" onClick={handlePrevious} disabled={startIndex === 0}>
          Previous
        </button>
        <button className="next-button" onClick={handleNext}>
          Next
        </button>
      </div>
    </div>
  );
};

export default VerticalLine;
