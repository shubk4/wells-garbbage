import React, { useState } from 'react';
import './slider.css';

const SliderComponent = () => {
  const [value1, setValue1] = useState(50);
  const [value2, setValue2] = useState(5);

  const handleSlider1Change = (event) => {
    setValue1(event.target.value);
  };

  const handleSlider2Change = (event) => {
    setValue2(event.target.value);
  };

  const handleCreateClick = () => {
    // Store the values in variables or perform any desired actions
    const variable1 = value1;
    const variable2 = value2;
    console.log('Variable 1:', variable1);
    console.log('Variable 2:', variable2);
  };

  return (
    <div className="slider-component">
      <h2>Slider Component</h2>
      <label>
        Slider 1: <span>{value1}</span>
      </label>
      <input
        type="range"
        min={0}
        max={100}
        value={value1}
        onChange={handleSlider1Change}
      />

      <label>
        Slider 2: <span>{value2}</span>
      </label>
      <input
        type="range"
        min={0}
        max={10}
        value={value2}
        onChange={handleSlider2Change}
      />

      <button onClick={handleCreateClick}>Create</button>
    </div>
  );
};

export default SliderComponent;
